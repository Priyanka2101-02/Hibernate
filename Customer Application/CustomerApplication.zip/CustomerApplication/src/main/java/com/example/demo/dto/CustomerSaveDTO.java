package com.example.demo.dto;

public class CustomerSaveDTO {
	private String cname;
	private String address;
	private int mobile;
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public CustomerSaveDTO(String cname, String address, int mobile) {
		super();
		this.cname = cname;
		this.address = address;
		this.mobile = mobile;
	}
	public CustomerSaveDTO() {
		super();
	}
	@Override
	public String toString() {
		return "CustomerSaveDTO [cname=" + cname + ", address=" + address + ", mobile=" + mobile + "]";
	}
	
	
	

}
