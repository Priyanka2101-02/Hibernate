package com.example.demo.enity;

import javax.persistence.*;

@Entity
@Table(name="customer")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	
	private int cid;
	@Column(name="customer_name", length=50)
	private String cname;
	@Column(name="customer_address", length=100)
	private String address;
	private int mobile;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public Customer( String cname, String address, int mobile) {
		super();
		//this.cid = cid;
		this.cname = cname;
		this.address = address;
		this.mobile = mobile;
	}
	public Customer() {
		super();
	}
	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", address=" + address + ", mobile=" + mobile + "]";
	}


}
