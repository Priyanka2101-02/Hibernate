package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.CustomerDTO;
import com.example.demo.dto.CustomerSaveDTO;
import com.example.demo.dto.CustomerUpdateDTO;

public interface CustomerService {

	String addCustomer(CustomerSaveDTO customerSaveDTO);
	List<CustomerDTO> getAllCustomer();
	
	String updateCustomer(CustomerUpdateDTO customerUpdateDTO);
	boolean deleteCustomer(int id);
	

}
