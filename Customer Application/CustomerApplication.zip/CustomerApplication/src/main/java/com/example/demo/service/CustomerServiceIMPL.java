package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.CustomerDTO;
import com.example.demo.dto.CustomerSaveDTO;
import com.example.demo.dto.CustomerUpdateDTO;
import com.example.demo.enity.Customer;
import com.example.demo.repository.CustomerRepo;
@Service
public class CustomerServiceIMPL implements CustomerService {
@Autowired
private CustomerRepo customerRepo;
	
	@Override
	public String addCustomer(CustomerSaveDTO customerSaveDTO) {
		Customer customer = new Customer(customerSaveDTO.getCname(), 
				customerSaveDTO.getAddress(), customerSaveDTO.getMobile());
		customerRepo.save(customer);
		return customer.getCname();
	}

//Get Customer
	@Override
	public List<CustomerDTO> getAllCustomer() {
		List<Customer>getCustomers=customerRepo.findAll();
		List<CustomerDTO>customerDTOList=new ArrayList<>();
		for(Customer a:getCustomers) {
			CustomerDTO customerDTO =new CustomerDTO(a.getCid(),
		a.getCname(), a.getAddress(), a.getMobile());
			
			customerDTOList.add(customerDTO);
		}
		
		return customerDTOList ;
	}
	
	//Update Customer 

	@Override
	public String updateCustomer(CustomerUpdateDTO customerUpdateDTO) {
		if(customerRepo.existsById(customerUpdateDTO.getCid()))
		{
			Customer customer=customerRepo.getById(customerUpdateDTO.getCid());
			customer.setCname(customerUpdateDTO.getCname());
			customer.setAddress(customerUpdateDTO.getAddress());
			customer.setMobile(customerUpdateDTO.getMobile());
			
			customerRepo.save(customer);
		
		}
		else
		{
			System.out.println("Customr is not exist!!");
		}
		
		return null;
	}

	@Override
	public boolean deleteCustomer(int id) {
		if(customerRepo.existsById(id))
		{
			customerRepo.deleteById(id);
		}
		else
		{
			System.out.println("ID is not exist!!");
		}
		return false;
	}
	
	

}
