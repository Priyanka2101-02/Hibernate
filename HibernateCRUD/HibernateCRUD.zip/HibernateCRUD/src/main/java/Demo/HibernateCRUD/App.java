package Demo.HibernateCRUD;

import Demo.HibernateCRUD.dao.StudentDao;
import Demo.HibernateCRUD.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	StudentDao sd=new StudentDao();
    	Student stud=new Student("Priyanka","Takale","priya@gmail.com");
    	sd.saveStudent(stud);
    	sd.insertStudent();
    	//update
    	Student s=new Student("Roohan","Takale","priya@gmail.com");
    	//sd.updateStudent(s);
    	sd.updateSudent(s);
    	
    }
}
