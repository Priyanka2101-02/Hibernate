package Demo.HibernateCRUD.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import Demo.HibernateCRUD.entity.Student;
import Demo.HibernateCRUD.util.HibernateUtil;

public class StudentDao {
	
	public void saveStudent(Student stud)
	{
		Transaction t =null;
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			//Start transaction
			session.beginTransaction();
			//fisrt operation 
			Object obj=session.save(stud);
			//sencond operation 
			session.get(Student.class,(Serializable) obj);
			//commit transaction 
			t.commit();
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}	
	}

	public void insertStudent()
	{

		Transaction t =null;
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			//Start transaction
			session.beginTransaction();
			String sql="INSERT INTO Student(firstname,lastname,email)"+
			"SELECT firstname,lastname,email from Student";
			
			Query query=session.createQuery(sql);
			int result =query.executeUpdate();
			System.out.println("Rows Affected!!"+result);
			t.commit();
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}
		
	}
	public void updateSudent(Student stud)
	{
		Transaction t=null;
		
		try (Session session=HibernateUtil.getSessionFactory().openSession()){
		//start transaction
			session.beginTransaction();
			//save the student object
			String hql = "UPDATE Student set firstname = :firstname " + "WHERE id = :studentId";
			Query query = session.createQuery(hql);
			query.setParameter("firstname", stud.getFirstname());
			query.setParameter("studentId", 1);
			int result=query.executeUpdate();
			System.out.println("Rows affected:"+result);
			t.commit();
			
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}
	}
	
	/*public void updateStudent(Student stud)
	{
		Transaction t =null;
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			//Start transaction
			session.beginTransaction();
			//save the student object 
			String sql="UPDATE Student set firstname=:firstname"+"where id=:studentId";
			Query query=session.createQuery(sql);
			query.setParameter("firstname", stud.getFirstname());
			query.setParameter("studentId",1);
			
			int result =query.executeUpdate();
			System.out.println("Rows Affected!!"+result);
			t.commit();
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}
	}*/
	
	public void deleteStudent(int id)
	{
		Transaction t =null;
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			//Start transaction
			session.beginTransaction();
			Student stud=session.get(Student.class, id);
			if(stud!=null)
			{
				String sql="DELETE FROM Student"+"where id=:id";
				Query query=session.createQuery(sql);
				
				query.setParameter("id",id);
				
				int result =query.executeUpdate();
				System.out.println("Rows Affected!!"+result);
			
			}	
			t.commit();
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}
		
	}
	
	public Student getStudent(int id)
	{
		Transaction t =null;
		Student stud=null;
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			//Start transaction
			session.beginTransaction();
			String sql="FROM Student S WHERE S.id=:id";
			
			Query query=session.createQuery(sql);
			
			query.setParameter("id",id);
			List result =query.getResultList();
			if(result!=null&&!result.isEmpty())
			{
				stud=(Student)result.get(0);
			}
			t.commit();
		}
		catch(Exception e)
		{
			if(t!=null)
			{
				t.rollback();
			}
			e.printStackTrace();
		}
		return stud;
	}
	
	public List<Student>getStudent()
	{
		try(Session session= HibernateUtil.getSessionFactory().openSession())
		{
			return session.createQuery("from Student",Student.class).list();
		}
	}
}
