package Demo.HibernateDemo;

import java.util.List;

import Demo.HibernateDemo.dao.StudentDao;
import Demo.HibernateDemo.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	StudentDao sd=new StudentDao ();
    	Student s=new Student("Priyanka","T","Priya@123@gmail.com");
    	sd.saveStudent(s);
    	List<Student>students=sd.getStudents();
    	students.forEach(st->System.out.println(st.getFirstname()));
    	
    }
}
