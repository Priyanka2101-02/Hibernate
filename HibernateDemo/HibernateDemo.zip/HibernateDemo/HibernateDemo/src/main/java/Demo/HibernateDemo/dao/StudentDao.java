package Demo.HibernateDemo.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Demo.HibernateDemo.entity.Student;
import Demo.HibernateDemo.util.HibernateUtil;

public class StudentDao {
	public void saveStudent(Student s)
	{
		Transaction t=null;
		try(Session session=HibernateUtil.getSessionFactory().openSession())
		{
			//start transaction
			t=session.beginTransaction();
			//operation 1
			Object obj=session.save(s);
			//opration2
			session.get(Student.class,(Serializable)obj);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
public List<Student>getStudents()
{
	try(Session session=HibernateUtil.getSessionFactory().openSession())
	{
	return session.createQuery("from Student",Student.class).list();	
	}
}
}
