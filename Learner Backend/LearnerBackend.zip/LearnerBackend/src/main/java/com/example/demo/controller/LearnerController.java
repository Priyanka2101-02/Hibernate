package com.example.demo.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Learner;
import com.example.demo.service.LearnerService;
@RestController //itselfs annonated with @Controller and @Response body(deserialize a request body into object)
@RequestMapping("api/learners")

public class LearnerController {

	public LearnerService learnerService;

	public LearnerController(LearnerService learnerService) {
		super();
		this.learnerService = learnerService;
	
		
		
	}
	//build employee rest API
	@PostMapping
	public ResponseEntity<Learner>saveLearner(@RequestBody Learner learner)
	{
		
		return new ResponseEntity<Learner>(learnerService.saveLearner(learner),HttpStatus.CREATED);
	}
	
	//build get learner REST API
	@GetMapping
	public List<Learner>getLearners()
	{
		return learnerService.getAllLearners();
	}
	
	@GetMapping("{id}")
	public ResponseEntity<Learner>getLearnerById(@PathVariable("id")long learnerId)
	{
		return new ResponseEntity<Learner>(learnerService.getLearnerById(learnerId),HttpStatus.OK);
	}
	
	@PutMapping("{id}")
	public ResponseEntity<Learner>updateLearner(@PathVariable("id")long  id,@RequestBody Learner learner)
	{
		return new  ResponseEntity<Learner>(learnerService.updateLearner(learner, id), HttpStatus.OK);
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<String>deleteLearner(@PathVariable("id")long  id)
	{
		learnerService.deleteLearner(id);
		return new ResponseEntity<String>("Learner Deleted!!",HttpStatus.OK);
	}
}
