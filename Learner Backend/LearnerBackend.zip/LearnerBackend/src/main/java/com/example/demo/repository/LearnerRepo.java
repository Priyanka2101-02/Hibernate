package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Learner;

public interface LearnerRepo extends JpaRepository<Learner,Long>{

	//jpa repository requires two parametr< entity, type of parameter>
	
	



}
