package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Learner;

public interface LearnerService {
	
	Learner saveLearner(Learner learner);
	List <Learner>getAllLearners();
	
	Learner getLearnerById(long id);
	Learner updateLearner(Learner learner, long id);
	void deleteLearner(long id);
	
	
	

}
