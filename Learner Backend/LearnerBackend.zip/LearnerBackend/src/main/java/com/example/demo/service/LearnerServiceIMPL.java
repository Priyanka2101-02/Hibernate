package com.example.demo.service;
import java.util.List;


import org.springframework.stereotype.Service;

import com.example.demo.entity.Learner;
import com.example.demo.exception.ResourceNotFound;
import com.example.demo.repository.LearnerRepo;
@Service
public class LearnerServiceIMPL implements LearnerService{
private LearnerRepo   learnerRepo ;
	
	public LearnerServiceIMPL(LearnerRepo learnerRepo) {
	super();
	this.learnerRepo = learnerRepo;
}

	@Override
	public Learner saveLearner(Learner learner) {
		
		return learnerRepo.save(learner);
	}

	@Override
	public List<Learner> getAllLearners() {
		
		return learnerRepo.findAll();
	}

	@Override
	public Learner getLearnerById(long id) {
		
		return learnerRepo.findById(id).orElseThrow(()->new ResourceNotFound("Learner","Id","id"));
	}

	@Override
	public Learner updateLearner(Learner learner, long id) {
		//we need to check whether id is there or not
		Learner existingLearner= learnerRepo.findById(id).orElseThrow(()->new ResourceNotFound("Learner","Id","id"));
		existingLearner.setFname(learner.getFname());
		existingLearner.setLname(learner.getLname());
		existingLearner.setAge(learner.getAge());
		existingLearner.setEmail(learner.getEmail());
		
		learnerRepo.save(existingLearner);
		
		return existingLearner;
	}

	@Override
	public void deleteLearner(long id) {
		
		learnerRepo.findById(id).orElseThrow(()->new ResourceNotFound("Learner","Id","id"));
		
		learnerRepo.deleteById(id);
	}
	
	

}
