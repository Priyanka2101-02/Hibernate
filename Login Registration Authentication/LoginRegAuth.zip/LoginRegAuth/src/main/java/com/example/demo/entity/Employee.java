package com.example.demo.entity;

import javax.persistence.*;
import javax.persistence.GenerationType;
@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="empId" ,length=50)
	private int id;
	
	@Column(name="empName",length=100)
	private String ename;
	
	@Column(name="empEmail",length=255)
	private String email;
	
	@Column(name="password",length=100)
	private String pass;

	public Employee(int id, String ename, String email, String pass) {
		super();
		this.id = id;
		this.ename = ename;
		this.email = email;
		this.pass = pass;
	}

	public Employee() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", ename=" + ename + ", email=" + email + ", pass=" + pass + "]";
	}
	
	
	
	

}
