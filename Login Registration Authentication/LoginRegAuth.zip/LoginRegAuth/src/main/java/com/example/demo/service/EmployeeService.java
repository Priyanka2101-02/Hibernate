package com.example.demo.service;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.LoginDTO;
import com.example.demo.responses.LoginResponse;

public interface EmployeeService {

	String addEmployee(EmployeeDTO employeedto);
	LoginResponse loginEmployee(LoginDTO logindto);
	
	
	
}
