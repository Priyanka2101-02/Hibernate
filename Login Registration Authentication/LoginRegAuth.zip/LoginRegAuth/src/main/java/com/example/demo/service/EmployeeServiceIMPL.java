package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.LoginDTO;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmpRepo;
import com.example.demo.responses.LoginResponse;
@Service
public class EmployeeServiceIMPL implements EmployeeService {
@Autowired
private EmpRepo emprepo;
@Autowired
private PasswordEncoder passwordEncoder;
	@Override
	public String addEmployee(EmployeeDTO empdto) {
		Employee employee=new Employee(
				empdto.getId(),
				empdto.getEname(),
				empdto.getEmail(),
				this.passwordEncoder.encode(empdto.getPassword())
				
				);
		emprepo.save(employee);
				
		return employee.getEname();
	}
EmployeeDTO empdto;
	@Override
	public LoginResponse loginEmployee(LoginDTO loginDTO) {
		String msg="";
		Employee emp1=emprepo.findByEmail(loginDTO.getEmail());
		if(emp1!=null)
		{
			String password=loginDTO.getPassword();
			String encodedPassword=emp1.getPassword();
			Boolean isPwdRight=passwordEncoder.matches(password, encodedPassword);
			if(isPwdRight)
			{
Optional<Employee>employee=emprepo.findOneByEmailAndPassword(loginDTO.getEmail(),encodedPassword);
			if(employee.isPresent())
			{
				return new LoginResponse("Login Successfully",true);
			}
			else
			{
				return new LoginResponse("Login Failed",false);
			}
			}else
			{
				return new LoginResponse("Password Not Match",false);
			}
		}else
		{
			return new LoginResponse("Email not exist",false);
	}
	}
}
		

