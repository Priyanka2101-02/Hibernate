package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.LoginDTO;
import com.example.demo.entity.Employee;
import com.example.demo.repository.EmpRepo;
import com.example.demo.responses.LoginResponse;
@Service

public class EmployeeServiceIMPL implements EmployeeService {
	@Autowired
	private EmpRepo emprepo;
	@Autowired
	private PasswordEncoder passwordencoder;
	@Override
	
	public String addEmployee(EmployeeDTO employeedto) {
		Employee emp=new Employee(
				employeedto.getId(),
				employeedto.getEname(),
				employeedto.getEmail(),
				this.passwordencoder.encode(employeedto.getPass())
				);
		
		emprepo.save(emp);
		return emp.getEname();
	}
	EmployeeDTO empdto;

	@Override
	public LoginResponse loginEmployee(LoginDTO logindto) {
		String msg="";
		Employee emp1=emprepo.findByEmail(logindto.getEmail());
		if(emp1!=null)
		{
			String password=logindto.getPass();
			System.out.println();
		String encodedPassword=emp1.getPass();
		
	boolean isPWDRight=passwordencoder.matches(password, encodedPassword);
	
	if(isPWDRight)
	{
		Optional<Employee>employee=emprepo.findOneByEmailAndPassword(logindto.getEmail(), encodedPassword);
		if(employee.isPresent())
		{
			return new LoginResponse("Login Successful",true);
		}
		else
		{
			return new LoginResponse("Login Failed",false);
		}
		
	}else
	{
		return new LoginResponse("Password Not Matched!!",false);
	}
		}
	else
	{
		return new LoginResponse("Email not exist",true);
	}
	
		}
		
		
	}

	

