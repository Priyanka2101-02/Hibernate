package Demo.manytomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Demo.manytomany.entity.Employee;
import Demo.manytomany.entity.Project;
import Demo.manytomany.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	SessionFactory sf=null;
    	Session s=null;
    	Transaction transaction=null;
    	try
    	{
    		sf=HibernateUtil.getSessionFactory();
    		s=sf.openSession();
    		transaction=s.beginTransaction();
    		Employee employee=new Employee();
    		employee.setFname("harry");
    		employee.setLname("Potter");
    		
    		Project p1=new Project();
    		p1.setTitle("java project");
    		
    		Project p2=new Project();
    		p2.setTitle("Python project");
    		
    		employee.getProjects().add(p1);
    		employee.getProjects().add(p2);
    		s.save(employee);
    		transaction.commit();
    	}catch(Exception e)
    	{
    		s.close();
    		sf.close();
    		System.out.println(e);
    	}
    	
    }
}
