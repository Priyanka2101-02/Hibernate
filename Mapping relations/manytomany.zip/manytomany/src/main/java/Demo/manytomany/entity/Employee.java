package Demo.manytomany.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity 
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue

	private int id;
	private String fname;
	private String lname;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name="employee_project",joinColumns= {
			@JoinColumn(name="employee_id")},inverseJoinColumns= {
					@JoinColumn(name="project_id") })
	Set<Project>projects=new HashSet<Project>();

	public Employee(String fname, String lname, Set<Project> projects) {
		super();
		
		this.fname = fname;
		this.lname = lname;
		this.projects = projects;
	}

	public Employee() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public Set<Project> getProjects() {
		return projects;
	}

	public void setProjects(Set<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", fname=" + fname + ", lname=" + lname + ", projects=" + projects + "]";
	}
	
	
	
	
	
	
}
