package Demo.manytomany.entity;

import java.util.*;

import javax.persistence.*;

@Entity 
@Table(name="project")
public class Project {
	
	
	@Id
	@GeneratedValue
	private int id;
	private String title;
	
	@ManyToMany(mappedBy = "projects", cascade = CascadeType.ALL)
	private Set<Employee>emp=new HashSet<Employee>();

	public Project() {
		super();
	}

	public Project(String title, Set<Employee> emp) {
		super();
		this.title = title;
		this.emp = emp;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<Employee> getEmp() {
		return emp;
	}

	public void setEmp(Set<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Project [id=" + id + ", title=" + title + ", emp=" + emp + "]";
	}
	
	
	
	
	
	
	
	

}
