package demo.onetomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import demo.onetomany.entity.Course;
import demo.onetomany.entity.Instructor;
import demo.onetomany.util.HibernateUtil;

public class FetchOp {

	public static void main(String[] args) {
		SessionFactory factory =null;
    	Session session=null;
    	Transaction transaction=null;
    	try
    	{
    		factory=HibernateUtil.getSessionFactory();
    		session=factory.openSession();
    		transaction=session.beginTransaction();
    		System.out.println(session.get(Instructor.class,1));
    		System.out.println(session.get(Course.class,2));
    		transaction.commit();
    	}
    	catch(Exception e)
    	{
    		
    	}

	}

}
