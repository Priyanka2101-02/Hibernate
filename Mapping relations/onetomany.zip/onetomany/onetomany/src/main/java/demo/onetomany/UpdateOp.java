package demo.onetomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import demo.onetomany.entity.Instructor;
import demo.onetomany.util.HibernateUtil;

public class UpdateOp {

	public static void main(String[] args) {
		SessionFactory factory =null;
    	Session session=null;
    	Transaction transaction=null;
    	try
    	{
    		factory=HibernateUtil.getSessionFactory();
    		session=factory.openSession();
    		transaction=session.beginTransaction();
    		
    		Instructor inst= session.get(Instructor.class,4);
    		inst.setEmail("priya21@gmail.com");
    		inst.setFirstname("priyanka");
    		inst.setLastname("Takale");
    		session.saveOrUpdate(inst);
    		transaction.commit();
    		
    		
    	}catch(Exception e)
    	{
    		session.close();
    		e.printStackTrace();
    	}
		
		
		
		

	}

}
