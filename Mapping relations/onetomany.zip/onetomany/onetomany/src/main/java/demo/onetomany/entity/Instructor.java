package demo.onetomany.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

@Entity
@Table(name="instructor")
public class Instructor {
	@Id
	@GeneratedValue
	private int Id;
	private String firstname;
	private String lastname;
	private String email;
	//creating one to many relation with course table
	@OneToMany(cascade = CascadeType.ALL)
	private List<Course> courses=new ArrayList<Course>();
	
	/*public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List <Course> getCourses()
	{
		return courses;
	}
	public void setCourses(List<Course>courses)
	{
		this.courses=courses;
	}*/
	
	
	public Instructor(String firstname, String lastname, String email) {
		super();
		//Id = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
	}
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Course> getCourses() {
		return courses;
	}
	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}
	
	
	public Instructor() {
		super();
	}
	@Override
	public String toString() {
		return "Instructor [Id=" + Id + ", firstname=" + firstname + ", lastname=" + lastname + ", email=" + email
				+ "]";
	}
	
	

}
