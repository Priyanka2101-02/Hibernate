package Demo.onetoonemapping;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import Demo.onetoonemapping.entity.InstructorDetail;
import Demo.onetoonemapping.util.HibernateUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
    	SessionFactory sessionFactory=null;
    	Session session=null;
    	try
    	{
    		sessionFactory=HibernateUtil.getSessionFactory();
    		session=sessionFactory.openSession();
    		Transaction transaction=session.beginTransaction();
    		 InstructorDetail Inst=session.get( InstructorDetail.class, 1);
    		 System.out.println(Inst.getSid());
    		 System.out.println(Inst.getHobby());
    		 System.out.println(Inst.getYoutubechannel());
    		 System.out.println(Inst.getInstructor().getEmail());
    		 System.out.println(Inst.getInstructor().getFirstname());
    		 transaction.commit();
    	}
    	catch(Exception e)
    	{
    		session.close();
    		sessionFactory.close();
    		System.out.println(e);
    		
    	}
    }
}
