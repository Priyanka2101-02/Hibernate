package Demo.onetoonemapping.entity;
import javax.persistence.*;


@Entity
@Table(name="instructor_detail")
public class InstructorDetail {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private int sid;
private String youtubechannel;
private String hobby;
	
@OneToOne(fetch = FetchType.LAZY)
@JoinColumn(name="id")
private Instructor instructor;

public InstructorDetail(int sid, String youtubechannel, String hobby, Instructor instructor) {
	super();
	this.sid = sid;
	this.youtubechannel = youtubechannel;
	this.hobby = hobby;
	this.instructor = instructor;
}

public InstructorDetail() {
	super();
}

public int getSid() {
	return sid;
}

public void setSid(int sid) {
	this.sid = sid;
}

public String getYoutubechannel() {
	return youtubechannel;
}

public void setYoutubechannel(String youtubechannel) {
	this.youtubechannel = youtubechannel;
}

public String getHobby() {
	return hobby;
}

public void setHobby(String hobby) {
	this.hobby = hobby;
}

public Instructor getInstructor() {
	return instructor;
}

public void setInstructor(Instructor instructor) {
	this.instructor = instructor;
}

@Override
public String toString() {
	return "InstructorDetail [sid=" + sid + ", youtubechannel=" + youtubechannel + ", hobby=" + hobby + ", instructor="
			+ instructor + "]";
}



}
