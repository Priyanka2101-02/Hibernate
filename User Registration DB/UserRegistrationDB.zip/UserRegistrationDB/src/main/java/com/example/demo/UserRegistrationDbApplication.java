package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserRegistrationDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserRegistrationDbApplication.class, args);
	}

}
